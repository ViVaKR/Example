def add(a, b):
    return a + b


def sub(a, b):
    return a - b


def mul(a, b):
    return a * b


def div(a, b):
    return a // b # 주석을 추가함, 토픽 브랜치와 충돌 발생용 

print(f"123 + 4546 = {add(123, 4546)}") 